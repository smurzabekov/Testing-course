package fuzzer;

import com.code_intelligence.jazzer.api.FuzzedDataProvider;
import org.json.JSONException;
import org.json.JSONObject;

public class MyFirstFuzzTarget {
    public static void fuzzerTestOneInput(FuzzedDataProvider data) {
        try {
            JSONObject jsonObject = new JSONObject(data.consumeRemainingAsString());
        } catch (JSONException e) {
        }
    }
}
