package fuzzer;

import com.code_intelligence.jazzer.api.FuzzedDataProvider;
import org.json.JSONArray;
import org.json.JSONException;

public class MyThirdFuzzTarget {
    public static void fuzzerTestOneInput(FuzzedDataProvider data) {
        try {
            JSONArray jsonArray = new JSONArray(data.consumeRemainingAsString());
            jsonArray.join(data.consumeRemainingAsString());
        } catch (JSONException e) {
        }
    }
}
