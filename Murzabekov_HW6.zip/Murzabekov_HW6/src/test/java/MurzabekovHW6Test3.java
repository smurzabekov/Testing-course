import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class MurzabekovHW6Test3 {
    public static WebDriver driver;
    public static PageElements page;
    public static String pageURL = "https://ruswizard.su/test/wp-login.php";
    public static String username1 = "superStar";
    public static String username2 = "test_user_4";
    public static String password = "12345";

    @BeforeClass
    public static void init() {
        System.setProperty("webdriver.chrome.driver", "D:\\Programs\\chromedriver.exe");
        driver = new ChromeDriver();
        page = new PageElements(driver);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void test3() {
        driver.get(pageURL);
        page.inputLogin(username1);
        page.inputPassword(password);
        page.clickLoginBtn();
        page.addPost();
        page.writeTitle("Murzabekov test 3");
        page.publishPost(false);
        driver.get("https://ruswizard.su/test/wp-admin/edit.php?post_type=post");
        driver.switchTo().alert().accept();
        WebElement post = driver.findElement(By.xpath("//*[text()='Murzabekov test 3']"));
        assertNotEquals(post, null);
        page.userLogout();
    }
}
