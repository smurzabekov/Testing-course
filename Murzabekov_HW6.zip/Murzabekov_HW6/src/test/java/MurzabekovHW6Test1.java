import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class MurzabekovHW6Test1 {
    public static WebDriver driver;
    public static PageElements page;
    public static String pageURL = "https://ruswizard.su/test/wp-login.php";
    public static String username1 = "superStar";
    public static String username2 = "test_user_4";
    public static String password = "12345";

    @BeforeClass
    public static void init() {
        System.setProperty("webdriver.chrome.driver", "С:\\chromedriver.exe");
        driver = new ChromeDriver();
        page = new PageElements(driver);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void test1() {
        driver.get(pageURL);
        page.inputLogin(username1);
        page.inputPassword(password);
        page.clickLoginBtn();
        page.addPost();
        page.writeTitle("Murzabekov test public post");
        page.publishPost(false);
        String postLink =  page.getLink(false);
        driver.get(postLink);
        page.userLogout();
        page.inputLogin(username2);
        page.inputPassword(password);
        page.clickLoginBtn();
        driver.get(postLink);
        assertTrue(page.isPublic());
        page.userLogout();
        driver.get(postLink);
        assertTrue(page.isPublic());
    }
}
