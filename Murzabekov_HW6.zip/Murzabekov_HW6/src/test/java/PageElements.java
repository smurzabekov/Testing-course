import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageElements {
    public WebDriver driver;

    public PageElements(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    @FindBy(xpath = "//*[@id=\"post-title-0\"]")
    private WebElement postTitle;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[1]/div[1]/div/button")
    private WebElement accessButton;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[2]/div/div/div/fieldset/div[2]/label")
    private WebElement privatePostButton;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[1]/div/div[2]/button")
    private WebElement publishButton;
    @FindBy(xpath = "//*[@id=\"inspector-checkbox-control-3\"]")
    private WebElement checkBoxPublish;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[4]/div[2]/div/div/div[1]/div[1]/button")
    private WebElement finalPublishButton;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[3]/div[2]/a/span[1]")
    private WebElement postLink;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[3]/div[2]/a/span[2]")
    private WebElement postLink2;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[3]/h2/button")
    private WebElement button;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[4]/div[2]/div/div/div[1]/button")
    private WebElement close_btn;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[3]/div/div[2]/ul/li[1]/button")
    private WebElement postButton;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[3]/div/div[3]/div[3]")
    private WebElement deletePostButton;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[4]/h2/button")
    private WebElement deferredButton1;
    @FindBy(xpath = "//*[@id=\"editor\"]/div[1]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[4]/div/div[1]/fieldset[2]/div/div/input[2]")
    private WebElement deferredInput;
    @FindBy(xpath = "//*[@id=\"user_login\"]")
    private WebElement loginField;
    @FindBy(xpath = "//*[@id=\"user_pass\"]")
    private WebElement passwordField;
    @FindBy(xpath = "//*[@id=\"wp-submit\"]")
    private WebElement loginBtn;
    @FindBy(xpath = "//*[@id=\"wp-admin-bar-my-account\"]/a")
    private WebElement userAvatar;
    @FindBy(xpath = "//*[@id=\"wp-admin-bar-user-info\"]/a/span")
    private WebElement usernameSpan;
    @FindBy(xpath = "//*[@id=\"wp-admin-bar-logout\"]/a")
    private WebElement logoutBtn;
    @FindBy(xpath = "//*[@id=\"wp-admin-bar-new-content\"]/a")
    private WebElement adminBarNewContent;
    @FindBy(xpath = "//*[@id=\"wp-admin-bar-new-post\"]/a")
    private WebElement adminBarNewPost;
    @FindBy(xpath = "//*[@id=\"menu-posts\"]/a/div[3]")
    private WebElement menuPosts;

    public void writeTitle(String title) {
        postTitle.sendKeys(title);
    }

    public void changeAccess() {
        accessButton.click();
        privatePostButton.click();
        driver.switchTo().alert().accept();
    }

    public void publishPost(boolean isPrivate) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.querySelector('button.components-button.editor-post-publish-panel__toggle.editor-post-publish-button__button.is-primary').click()");
        if (!isPrivate) {
            finalPublishButton.click();
        }
    }

    public String getLink(boolean isPrivate) {
        if (!isPrivate) {
            close_btn.click();
        }
        else {
            postButton.click();
        }

        button.click();
        return postLink.getText() + postLink2.getText();
    }

    public void deletePost() {
        deletePostButton.click();
        try {
            Thread.sleep(500);
        }
        catch (InterruptedException e) {}
    }

    public void publishDelayedPost() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.querySelector('button.components-button.editor-post-publish-panel__toggle.editor-post-publish-button__button.is-primary').click()");
        deferredButton1.click();
        int val = Integer.parseInt(deferredInput.getAttribute("value")) + 1;
        System.out.println(val);
        deferredInput.sendKeys(String.format("%s", val));

        finalPublishButton.click();
        try {
            Thread.sleep(60000);
        }
        catch (InterruptedException e) {}
    }

    public void inputLogin(String username) {
        loginField.clear();
        loginField.sendKeys(username);
    }

    public void inputPassword(String password) {
        passwordField.sendKeys(password);
    }

    public void clickLoginBtn() {
        loginBtn.click();
    }

    public boolean isPublic() {
        return !driver.findElement(By.tagName("h1")).getText().equals("Страница не найдена");
    }

    public void userLogout() {
        Actions builder = new Actions(driver);
        builder.moveToElement(userAvatar).build().perform(); //навести курсор на иконку пользователя для открытия меню
        logoutBtn.click();
    }

    public void addPost() {
        Actions builder = new Actions(driver);
        builder.moveToElement(adminBarNewContent).build().perform(); //навести курсор на иконку пользователя для открытия меню
        adminBarNewPost.click();
    }
}
