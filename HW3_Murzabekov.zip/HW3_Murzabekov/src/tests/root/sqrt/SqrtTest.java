package root.sqrt;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Тесты написаны на JUnit 5.4.
 */
public class SqrtTest {
    private static double EPS;
    private static AdvSqrt sqrt;

    @BeforeAll
    public static void init() {
        EPS = 2.25e-16;
        sqrt = new AdvSqrt();
    }

    @AfterAll
    public static void detach() {
        sqrt = null;
    }

    @Test
    public void testIntDigit() {
        assertEquals(17, sqrt.sqrt(289), EPS);
    }

    @Test
    public void testDenormalized() {
        double dnrd = Double.longBitsToDouble(0x0000000001000000L);
        assertEquals(Math.sqrt(dnrd), sqrt.sqrt(dnrd), EPS);
    }

    @Test
    public void testNegative() {
        assertEquals(Double.NaN, sqrt.sqrt(-81));
    }

    @Test
    public void testNegativeInf() {
        assertEquals(Double.NaN, sqrt.sqrt(Double.NEGATIVE_INFINITY));
    }

    @Test
    public void testPositiveInf() {
        assertEquals(Double.POSITIVE_INFINITY, sqrt.sqrt(Double.POSITIVE_INFINITY));
    }

    @Test
    public void testDoubleDigit() {
        assertEquals(Math.sqrt(15894), sqrt.sqrt(15894), EPS);
    }

    @Test
    public void testZero() {
        assertEquals(0, sqrt.sqrt(0), EPS);
    }

    @Test
    public void testMinusZero1() {
        assertEquals(-0, sqrt.sqrt(-0), EPS);
    }

    @Test
    public void testMinusZero2() {
        assertEquals(-.0, sqrt.sqrt(-.0), EPS);
    }

    @Test
    public void testNAN() {
        assertEquals(Double.NaN, sqrt.sqrt(Double.NaN));
    }

    @Test
    public void testOne() {
        assertEquals(1, sqrt.sqrt(1), EPS);
    }

}
