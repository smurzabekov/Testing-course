package root.gcd;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Тесты написаны на JUnit 5.4.
 */
public class GCDTest {
    private static GCD gcd;

    @BeforeAll
    public static void init() {
        gcd = new GCD();
    }

    @AfterAll
    public static void detach() {
        gcd = null;
    }

    @Test
    @DisplayName("Тест проверяет, что первый аргумент делится нацело на результат gcd.")
    public void firstArgumentDivideOnResult() {
        int result = gcd.gcd(25, 75);
        assertEquals(0, 25 % result, "The MOD must be zero.");
    }

    @Test
    @DisplayName("Тест проверяет, что второй аргумент делится нацело на результат gcd.")
    public void secondArgumentDivideOnResult() {
        int result = gcd.gcd(25, 75);
            assertEquals(0, 75 % result, "The MOD must be zero.");
    }

    @Test
    @DisplayName("Среди всех общих делителей аргументов результат является наибольшим по абсолютной величине.")
    public void divTheGreatest() {
        int result = gcd.gcd(14, 17);
            int psDiv = Math.min(Math.abs(14), Math.abs(17));
            while (psDiv > result) {
                assertFalse(14 % psDiv == 0 && 17 % psDiv == 0, "The result must be the biggest of all ");
                psDiv--;
            }
    }

    @Test
    @DisplayName("Результат неотрицателен.")
    public void resultIsPositive() {
        int result = gcd.gcd(-5, 16);
            assertTrue(result > 0, "The gcd must be greater than zero.");
    }

    @Test
    @DisplayName("Положительные значения аргументов.")
    public void positiveArgs(){
        assertEquals(25, gcd.gcd(25, 75));
    }

    @Test
    @DisplayName("Отрицательный первый аргумент.")
    public void negFirst(){
        assertTrue(gcd.gcd(-3, 30) > 0);
    }

    @Test
    @DisplayName("Отрицательный второй аргумент.")
    public void negSecond(){
        assertTrue(gcd.gcd(7, -2) > 0);
    }

    @Test
    @DisplayName("Отрицательные оба аргумента.")
    public void negBoth(){
        assertTrue(gcd.gcd(7, -2) > 0);
    }

    @Test
    @DisplayName("Нулевой первый аргумент.")
    public void zeroFirst(){
        assertEquals(30, gcd.gcd(0, 30));
    }

    @Test
    @DisplayName("Нулевой второй аргумент.")
    public void zeroSecond(){
        assertEquals(7, gcd.gcd(7, 0));
    }

    @Test
    @DisplayName("НОД двух нулей.")
    public void bothZeros() {
        assertEquals(0, gcd.gcd(0, 0));
    }

    @Test
    @DisplayName("Неединичные взаимно простые аргументы.")
    public void mutuallySimple(){
        assertEquals(1, gcd.gcd(17, 22));
    }

    @Test
    @DisplayName("Равные значения аргументов.")
    public void twinsArgs(){
        int f = 16, s = 16;
        int result = gcd.gcd(f, s);
        assertTrue(result == f && result == s);
    }
    @Test
    @DisplayName("Неравные значения аргументов, первый делит второй.")
    public void gcdEqualsMinFirst(){
        int result = gcd.gcd(30, 180);
        assertEquals(30, result);
    }

    @Test
    @DisplayName("Неравные значения аргументов, второй делит первый.")
    public void gcdEqualsMinSecond(){
        int result = gcd.gcd(180, 30);
        assertEquals(30, result);
    }

    @Test
    @DisplayName("Неравные значения аргументов, дающие неединичный НОД.")
    public void gcdNotOne(){
        assertNotEquals(1, gcd.gcd(14, 21));
    }

    @Test
    @DisplayName("Граничные значения.")
    void gcdBordersVals() {
        assertTimeoutPreemptively(Duration.ofMillis(100), () -> {
            gcd.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE);
        });
    }
}
