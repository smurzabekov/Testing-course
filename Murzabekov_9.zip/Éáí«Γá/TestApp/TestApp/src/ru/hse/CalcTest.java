package ru.hse;

import com.code_intelligence.jazzer.api.FuzzedDataProvider;

public class CalcTest{

    public static void fuzzerTestOneInput(FuzzedDataProvider p) {
        try{
            String s = p.consumeRemainingAsString();
            System.out.println(s);
            Calc.calculate(s);
        } catch (CalcException ignored) {
        }
    }
}
